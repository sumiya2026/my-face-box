from flask import Flask, render_template, request, jsonify

app = Flask(__name__)

@app.route('/')
def index():
    return render_template('index.html')

@app.route('/scan-id', methods=['POST'])
def scan_id():
    return jsonify({
        'success': True,
        'id_number': '199912345678',
        'address': 'No. 44/A, 3rd Lane, Wadduwa'
    })

@app.route('/register-user', methods=['POST'])
def register_user():
    user_data = request.json
    print("New User Registered:", user_data)
    return jsonify({'success': True, 'message': 'Registered successfully!'})

if __name__ == '__main__':
    app.run(host='0.0.0.0', port=5000, debug=True)


