import os

html_path = "index.html"

if os.path.exists(html_path):
    with open(html_path, "r", encoding="utf-8") as f:
        content = f.read()

    # 1. <head> ටැගය අවසානයට i18n ක්‍රියාකාරීත්වය සහ Styles එකතු කිරීම
    if "</head>" in content and "langSelect" not in content:
        dropdown_html = """
        <div class="language-selector" style="position: fixed; right: 15px; top: 15px; z-index: 10000;">
            <select id="langSelect" onchange="changeLanguage(this.value)" style="padding: 6px 10px; border-radius: 20px; font-weight: bold; border: 2px solid #1877f2; background: white; color: #1877f2; cursor: pointer; box-shadow: 0px 4px 6px rgba(0,0,0,0.1);">
                <option value="en">English</option>
                <option value="si">සිංහල</option>
                <option value="ta">தமிழ்</option>
            </select>
        </div>
        """
        content = content.replace("</head>", f"{dropdown_html}\n</head>")

    # 2. </body> ටැගයට පෙර භාෂාවන් මාරු වීමට අවශ්‍ය JavaScript එකතු කිරීම
    if "</body>" in content and "changeLanguage" not in content:
        js_code = """
        <script>
        let translations = {};
        fetch('/translations.json')
            .then(response => response.json())
            .then(data => {
                translations = data;
                const savedLang = localStorage.getItem('selectedLanguage') || 'en';
                const selectEl = document.getElementById('langSelect');
                if(selectEl) selectEl.value = savedLang;
                changeLanguage(savedLang);
            }).catch(err => console.error("Error loading translations:", err));

        function changeLanguage(lang) {
            localStorage.setItem('selectedLanguage', lang);
            document.querySelectorAll('[data-i18n]').forEach(element => {
                const key = element.getAttribute('data-i18n');
                if (translations[lang] && translations[lang][key]) {
                    if (element.tagName === 'INPUT' || element.tagName === 'TEXTAREA') {
                        element.placeholder = translations[lang][key];
                    } else {
                        element.innerText = translations[lang][key];
                    }
                }
            });
        }
        </script>
        """
        content = content.replace("</body>", f"{js_code}\n</body>")

    # 3. පවතින අකුරු i18n Tags වලට හැරවීම (පින්තූරයේ ඇති ප්‍රධාන වචන)
    content = content.replace("My Face BOX", '<span data-i18n="title">My Face BOX</span>')
    content = content.replace("Feed", '<span data-i18n="feed">Feed</span>')
    content = content.replace("Mind Chat", '<span data-i18n="mindChat">Mind Chat</span>')
    content = content.replace("Stories & Reels", '<span data-i18n="storiesReels">Stories & Reels</span>')
    content = content.replace("Create Story", '<span data-i18n="createStory">Create Story</span>')
    content = content.replace("What's on your mind?", 'What\'s on your mind?')
    content = content.replace("Post", '<span data-i18n="post">Post</span>')
    content = content.replace("No posts available yet.", '<span data-i18n="noPosts">No posts available yet.</span>')
    content = content.replace("Verify Identity & Create Account (Real Users Only)", '<span data-i18n="verifyBtn">Verify Identity & Create Account (Real Users Only)</span>')

    with open(html_path, "w", encoding="utf-8") as f:
        f.write(content)
    print("[SUCCESS] HTML file updated with 3 languages smoothly!")
else:
    print("[ERROR] index.html not found in this folder.")
