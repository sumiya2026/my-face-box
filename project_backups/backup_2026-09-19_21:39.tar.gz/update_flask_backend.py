import os

app_path = "app.py"

backend_structure = """from flask import Flask, request, jsonify, render_template
import os
import re

app = Flask(__name__, static_folder='.', static_url_path='')

# 🗄️ දත්ත තාවකාලිකව ගබඩා කරන ස්ථාන (Database Lists)
posts = [
    {
        "id": 1,
        "author": "Ape Media",
        "author_avatar": "/static/default_user.png",
        "time": "1h",
        "content": "රැල්ලියෙන් පසු තිස්සකුට්ටි පළමු වරට මාධ්‍ය ඉදිරියට...",
        "image": "https://placeholder.com", # පසුව සැබෑ පින්තූර දැමිය හැක
        "video": None,
        "likes": 238,
        "comments": [{"user": "කුමාර", "text": "නියමයි!"}],
        "shares": 65
    }
]

stories = [
    {"id": 1, "user": "Create story", "avatar": "/static/my_avatar.png", "bg": "", "is_me": True},
    {"id": 2, "user": "Saduni Maheshika", "avatar": "https://placeholder.com", "bg": "https://placeholder.com", "is_me": False},
    {"id": 3, "user": "Shalika Gangani", "avatar": "https://placeholder.com", "bg": "https://placeholder.com", "is_me": False}
]

@app.route('/')
def home():
    if os.path.exists('index.html'):
        with open('index.html', 'r', encoding='utf-8') as f:
            return f.read()
    return "index.html not found"

@app.route('/translations.json')
def get_translations():
    if os.path.exists('translations.json'):
        with open('translations.json', 'r', encoding='utf-8') as f:
            return f.read(), 200, {'Content-Type': 'application/json'}
    return '{"error": "Not Found"}', 404

# 🛡️ ජාතික හැඳුනුම්පත් (NIC) ඔටෝ සර්ච් API
@app.route('/api/verify-nic', methods=['POST'])
def verify_nic():
    data = request.get_json() or {}
    nic = data.get('nic', '').strip()
    if not nic:
        return jsonify({"success": False, "message": "කරුණාකර හැඳුනුම්පත් අංකය ඇතුළත් කරන්න."})
    
    old_nic_pattern = re.compile(r'^[0-9]{9}[vVxX]$')
    new_nic_pattern = re.compile(r'^[0-9]{12}$')
    
    if old_nic_pattern.match(nic) or new_nic_pattern.match(nic):
        return jsonify({"success": True, "message": "ජාතික හැඳුනුම්පත සත්‍ය බව තහවුරුයි!"})
    return jsonify({"success": False, "message": "අවලංගු හැඳුනුම්පත් අංකයකි!"})

# 📰 Posts සහ Stories ලබාගැනීමේ APIs
@app.route('/api/get-feed', methods=['GET'])
def get_feed():
    return jsonify({"posts": posts, "stories": stories})

# 📝 අලුත් Post එකක් පින්තූරයක් සමඟ දැමීමේ API
@app.route('/api/create-post', methods=['POST'])
def create_post():
    data = request.get_json() or {}
    content = data.get('content', '')
    image_url = data.get('image', None)
    
    new_post = {
        "id": len(posts) + 1,
        "author": "සුමියා (Sumiya)",
        "author_avatar": "https://placeholder.com",
        "time": "Just now",
        "content": content,
        "image": image_url,
        "video": None,
        "likes": 0,
        "comments": [],
        "shares": 0
    }
    posts.insert(0, new_post)
    return jsonify({"success": True, "post": new_post})

if __name__ == '__main__':
    app.run(host='0.0.0.0', port=5001, debug=True)
"""

with open(app_path, "w", encoding="utf-8") as f:
    f.write(backend_structure)
print("[SUCCESS] Advanced Social Media Backend Structure Ready!")
