import os

html_path = "index.html"

if os.path.exists(html_path):
    with open(html_path, "r", encoding="utf-8") as f:
        content = f.read()

    # මුළු මුහුණතේම හැඩතල සහ අකුරු තවත් දෙගුණයකින් (2x) විශාල කිරීමට CSS එක යාවත්කාලීන කිරීම
    # පැරණි <style> කොටස සම්පූර්ණයෙන්ම වඩාත් උසස් සහ විශාල මෝස්තර පද්ධතියකට හැරවීම
    
    giant_css = """<style>
        body {
            font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, Helvetica, Arial, sans-serif;
            
            margin: 0;
            padding: 0;
            font-size: 38px; /* අකුරු සැලකිය යුතු ලෙස විශාල කරන ලදී */
        }
        
        /* 🔵 ඉහළ තීරුව (Header Layout) */
        .fb-header {
            
            padding: 35px 30px; /* ඉඩකඩ වැඩි කරන ලදී */
            display: flex;
            align-items: center;
            justify-content: space-between;
            border-bottom: 2px solid #e4e6eb;
            position: relative;
        }
        .logo-section {
            display: flex;
            align-items: center;
        }
        .fb-logo {
            font-size: 64px; /* ලෝගෝ එක විශාල කරන ලදී */
            font-weight: bold;
            color: #1877f2;
            text-decoration: none;
        }
        
        /* 🌐 භාෂා මෙනුව වම්පැත්තේ හිස් තැනට */
        .language-selector {
            margin-left: 40px;
        }
        #langSelect {
            font-size: 32px; /* මෙනුවේ අකුරු විශාල කරන ලදී */
            padding: 12px 25px;
            border-radius: 30px;
            border: 3px solid #1877f2;
            
            color: #1877f2;
            font-weight: bold;
            cursor: pointer;
        }
        
        .header-icons {
            display: flex;
            gap: 25px;
        }
        .icon-btn {
            
            border: none;
            width: 90px; /* අයිකන් වටකුරු බොත්තම් විශාල කරන ලදී */
            height: 90px;
            border-radius: 50%;
            font-size: 42px;
            display: flex;
            align-items: center;
            justify-content: center;
            cursor: pointer;
        }

        /* ✍️ What's on your mind තීරුව */
        .mind-box {
            
            padding: 35px;
            margin-top: 20px;
            display: flex;
            gap: 30px;
            align-items: center;
            border-bottom: 2px solid #e4e6eb;
        }
        .user-avatar {
            width: 110px; /* පරිශීලක රූපය විශාල කරන ලදී */
            height: 110px;
            border-radius: 50%;
            
        }
        .mind-input {
            flex: 1;
            
            border-radius: 60px;
            padding: 30px 40px;
            font-size: 36px;
            border: none;
            outline: none;
            cursor: pointer;
        }

        /* 📸 Stories (කතන්දර) බාර් එක */
        .stories-wrapper {
            
            padding: 35px 25px;
            margin-top: 20px;
            display: flex;
            gap: 25px;
            overflow-x: auto;
        }
        .story-card {
            min-width: 260px; /* ස්ටෝරි කාඩ්ස් දෙගුණයකින් විශාල කරන ලදී */
            height: 440px;
            border-radius: 25px;
            
            position: relative;
            overflow: hidden;
            box-shadow: 0 4px 8px rgba(0,0,0,0.15);
        }
        .story-avatar {
            position: absolute;
            top: 25px;
            left: 25px;
            width: 80px;
            height: 80px;
            border-radius: 50%;
            border: 4px solid #1877f2;
            z-index: 2;
        }
        .story-name {
            position: absolute;
            bottom: 25px;
            left: 25px;
            color: white;
            font-size: 30px;
            font-weight: bold;
            text-shadow: 2px 2px 6px rgba(0,0,0,0.9);
            z-index: 2;
        }

        /* 📰 News Feed පෝස්ට් කාඩ් */
        .feed-container {
            padding: 25px;
        }
        .post-card {
            
            border-radius: 25px;
            padding: 40px;
            margin-bottom: 35px;
            box-shadow: 0 2px 6px rgba(0,0,0,0.1);
        }
        .post-header {
            display: flex;
            align-items: center;
            gap: 25px;
            margin-bottom: 25px;
        }
        .post-author {
            font-weight: bold;
            font-size: 38px;
        }
        .post-time {
            color: #65676b;
            font-size: 28px;
            margin-top: 5px;
        }
        .post-content {
            font-size: 36px;
            line-height: 1.5;
            margin-bottom: 25px;
        }
        .post-image {
            width: 100%;
            border-radius: 15px;
            margin-bottom: 25px;
        }
        
        /* Like, Comment බටන් */
        .post-actions {
            display: flex;
            justify-content: space-between;
            border-top: 2px solid #e4e6eb;
            padding-top: 25px;
            color: #65676b;
            font-weight: bold;
            font-size: 34px;
        }
        .action-item {
            display: flex;
            align-items: center;
            gap: 10px;
            cursor: pointer;
        }
    </style>"""

    # පවතින පැරණි ස්ටයිල් කොටස වෙනුවට අලුත් යෝධ ස්ටයිල් එක ආදේශ කිරීම
    if "<style>" in content and "</style>" in content:
        start_idx = content.find("<style>")
        end_idx = content.find("</style>") + len("</style>")
        content = content[:start_idx] + giant_css + content[end_idx:]
    else:
        # ස්ටයිල් එකක් නොතිබුනේ නම් හෙඩ් එකට ඇතුල් කිරීම
        content = content.replace("</head>", f"{giant_css}\n</head>")

    # පෝස්ට් ඇක්ෂන්ස් අයිතම වඩාත් විශාලව සහ පිළිවෙළට පෙන්වීමට HTML කොටස යාවත්කාලීන කිරීම
    content = content.replace("<div>👍 Like", '<div class="action-item">👍 Like')
    content = content.replace("<div>💬 Comment", '<div class="action-item">💬 Comment')
    content = content.replace("<div>↪️ Share", '<div class="action-item">↪️ Share')

    with open(html_path, "w", encoding="utf-8") as f:
        f.write(content)
    print("[SUCCESS] UI upscaled by 2x more! Perfectly fitted for mobile layout.")
else:
    print("[ERROR] index.html not found.")
