<!DOCTYPE html>
<html lang="en">
<head>
    <meta name="viewport" content="width=device-width, initial-scale=0.75, maximum-scale=5.0, user-scalable=yes" />
        <script async src="https://www.googletagmanager.com/gtag/js?id=G-S72LBY47R8"></script>
    <script>
      window.dataLayer = window.dataLayer || [];
      function gtag(){dataLayer.push(arguments);}
      gtag('js', new Date());
      gtag('config', "G-S72LBY47R8");
    </script>
    <meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
    <title>Pastebin.com - #1 paste tool since 2002!</title>
    <link rel="shortcut icon" href="/favicon.ico" />
    <meta name="description" content="Pastebin.com is the number one paste tool since 2002. Pastebin is a website where you can store text online for a set period of time." />
    <meta property="og:description" content="Pastebin.com is the number one paste tool since 2002. Pastebin is a website where you can store text online for a set period of time." />
            <meta property="fb:app_id" content="231493360234820" />
    <meta property="og:title" content="Pastebin.com - #1 paste tool since 2002!" />
    <meta property="og:type" content="article" />
    <meta property="og:url" content="https://pastebin.com/" />
    <meta property="og:image" content="https://pastebin.com/i/facebook.png" />
    <meta property="og:site_name" content="Pastebin" />
    <meta name="google-site-verification" content="jkUAIOE8owUXu8UXIhRLB9oHJsWBfOgJbZzncqHoF4A" />
    <link rel="canonical" href="https://pastebin.com/" />
        <meta name="csrf-param" content="_csrf-frontend">
<meta name="csrf-token" content="AEKt33y7N7OH5Ct6if-C1QJI25xojGTe5a2mHdZ7kvxFJPKUTMtAxreybjbznPWtexuf7VnNALW_-Mx5mw6rsQ==">

<link href="/assets/c80611c4/css/bootstrap.min.css" rel="stylesheet">
<link href="/assets/ff2ff0b/css/select2.min.css" rel="stylesheet">
<link href="/assets/c19c6973/css/select2-addl.min.css" rel="stylesheet">
<link href="/assets/c19c6973/css/select2-default.min.css" rel="stylesheet">
<link href="/assets/fb16b45a/css/kv-widgets.min.css" rel="stylesheet">
<link href="/assets/d65ff796/dist/bootstrap-tagsinput.css" rel="stylesheet">
<script>var s2options_7ebc6538 = {"themeCss":".select2-container--default","sizeCss":"","doReset":true,"doToggle":false,"doOrder":false};
window.select2_662ea3af = {"theme":"default","width":"100%","language":"en"};
window.select2_a09a7382 = {"theme":"default","width":"100%","minimumResultsForSearch":Infinity,"language":"en"};</script>    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/codemirror/5.58.2/codemirror.min.css" />
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/codemirror/5.58.2/theme/material-darker.min.css" />    
<link href="/themes/pastebin/css/vendors.bundle.css?30d6ece6979ee0cf5531" rel="stylesheet">
<link href="/themes/pastebin/css/app.bundle.css?30d6ece6979ee0cf5531" rel="stylesheet">
    
<!-- 0-EykQt2a9 -->
<script type="text/javascript" src="//services.vlitag.com/adv1/?q=adf050ece17b957604b4bbfc1829059f" defer="" async=""></script><script> var vitag = vitag || {};</script>
<!-- End Valueimpression Head Script -->

</head>
<body class="night-auto " data-pr="EykQt2a9" data-pa="" data-sar="1" data-abd="1" data-bd="1">


<svg style="height: 0; width: 0; position: absolute; visibility: hidden" xmlns="http://www.w3.org/2000/svg">
    <symbol id="add" viewBox="0 0 1024 1024"><path fill="#ccc" d="M512 16C238 16 16 238 16 512s222 496 496 496 496-222 496-496S786 16 512 16z m288 552c0 13.2-10.8 24-24 24h-184v184c0 13.2-10.8 24-24 24h-112c-13.2 0-24-10.8-24-24v-184h-184c-13.2 0-24-10.8-24-24v-112c0-13.2 10.8-24 24-24h184v-184c0-13.2 10.8-24 24-24h112c13.2 0 24 10.8 24 24v184h184c13.2 0 24 10.8 24 24v112z"/></symbol>
    <symbol id="search" viewBox="0 0 512 512"><path fill="#ccc" d="M354.2,216c0-38.2-13-70.7-40-97.7c-27-27-59.6-40-97.7-40s-70.7,13-97.7,40s-40,59.6-40,97.7 s13,70.7,40,97.7s59.6,40,97.7,40s70.7-13,97.7-40C340.2,285.8,354.2,253.2,354.2,216z M511.5,472c0,10.2-3.7,19.5-12.1,27.9 c-8.4,8.4-16.8,12.1-27.9,12.1c-11.2,0-20.5-3.7-27.9-12.1L339.3,393.8c-37.2,26.1-78.2,38.2-122.9,38.2 c-29.8,0-57.7-5.6-83.8-16.8c-27-11.2-50.3-27-68.9-46.5s-34.4-42.8-46.5-68.9C6.1,272.8,0.5,244.8,0.5,216s5.6-57.7,16.8-83.8 c11.2-27,27-50.3,46.5-68.9s42.8-34.4,68.9-46.5C159.7,5.6,187.6,0,216.4,0s57.7,5.6,83.8,16.8c27,11.2,50.3,27,68.9,46.5 c18.6,19.5,34.4,42.8,46.5,68.9c11.2,27,16.8,54.9,16.8,83.8c0,44.7-13,85.6-38.2,122.9L499.4,444 C507.8,451.5,511.5,460.8,511.5,472z"/></g></symbol>
</svg>
<div class="wrap">

        
        
<div class="header">
    <div class="container">
        <div class="header__container">

                        <div class="header__left">
                <a class="header__logo" href="/">
                    Pastebin                </a>

                <div class="header__links h_1024">
                    
                                        <a href="/doc_api">API</a>
                    <a href="/tools">tools</a>
                    <a href="/faq">faq</a>
                                    </div>

                <a class="header__btn" href="/">
                    <span>paste</span>
                </a>

                
                <div class="header__search">
                                            <form id="w0" class="search_form" action="https://pastebin.com/search" method="get">
                            
<input type="text" id="q" class="search_input" name="q" maxlength="128" placeholder="Search...">



                            <button type="submit" class="search_btn" aria-label="Search"><svg class="icon search"><use xlink:href="#search"></use></svg></button>
                        </form>                                    </div>

            </div>

                        <div class="header__right">

                                    <div class="header_sign">
                        <a href="/login" class="btn-sign sign-in">Login</a>
                        <a href="/signup" class="btn-sign sign-up">Sign up</a>
                    </div>
                
            </div>

        </div>
    </div>

</div>
        

    <div class="container">
        <div class="content">

                        
                        
<!-- 0-EykQt2a9 -->
<div style="padding-bottom:20px; padding-top:20px;">
<script>
  atOptions = {
    'key' : '210e136e94ad378e1be5d51f1002ed14',
    'format' : 'iframe',
    'height' : 90,
    'width' : 728,
    'params' : {}
  };
</script>
<script src="https://www.highrevenueformat.com/210e136e94ad378e1be5d51f1002ed14/invoke.js"></script>

</div>

                                    
            
            
<div class="post-create">

    
<div class="post-form  js-post-form">

    <form id="w0" class="js-create-form form-horizontal" action="/" method="post" enctype="multipart/form-data">
<input type="hidden" name="_csrf-frontend" value="KaGE3vpZRFAY6Bqv3jJNzOo6oB1HuJGA75m-dyOXJ1ZPlN3vkiFxKHWcaZ-ZSCX_iQ76cBSM4fqw6-QNT-VVbg==">
    <div class="error-summary" style="display:none"><p>Please fix the following errors:</p><ul></ul></div>
    <div class="content__title -no-border">
        New Paste
        
        
        <div class="post-form__live-code">
            <div class="toggle">
                <span class="toggle__text">Syntax Highlighting</span>
                <div class="toggle__control">
                    <input id="paste-raw-on" type="checkbox" class="js-live-code-highlight">
                    <label for="paste-raw-on"></label>
                </div>
            </div>
        </div>
    </div>

    
    <div class="form-group field-postform-text required">


<textarea id="postform-text" class="textarea -form js-paste-code" name="PostForm[text]" aria-label="New Paste" aria-required="true"></textarea>
</div>
    <div class="content__title -paste">Optional Paste Settings</div>

    <div class="post-form__bottom">
        <div class="post-form__left">

            <div class="form-group field-postform-category_id">
<label class="control-label col-sm-3" for="postform-category_id">Category:</label>
<div class="col-sm-9 field-wrapper">
<div class="kv-plugin-loading loading-postform-category_id">&nbsp;</div><select id="postform-category_id" class="form-control" name="PostForm[category_id]" data-s2-options="s2options_7ebc6538" data-krajee-select2="select2_662ea3af" style="width: 1px; height: 1px; visibility: hidden;">
<option value="0">None</option>
<option value="5">Cryptocurrency</option>
<option value="4">Cybersecurity</option>
<option value="7">Fixit</option>
<option value="8">Food</option>
<option value="9">Gaming</option>
<option value="10">Haiku</option>
<option value="11">Help</option>
<option value="12">History</option>
<option value="13">Housing</option>
<option value="14">Jokes</option>
<option value="15">Legal</option>
<option value="16">Money</option>
<option value="6">Movies</option>
<option value="17">Music</option>
<option value="18">Pets</option>
<option value="19">Photo</option>
<option value="20">Science</option>
<option value="21">Software</option>
<option value="27">Source Code</option>
<option value="22">Spirit</option>
<option value="23">Sports</option>
<option value="24">Travel</option>
<option value="25">TV</option>
<option value="26">Writing</option>
</select>

</div>
</div>
            <div class="form-group field-postform-tag">
<label class="control-label col-sm-3" for="postform-tag">Tags:</label>
<div class="col-sm-9 field-wrapper">
<input type="text" id="postform-tag" class="form-control" name="PostForm[tag]">

</div>
</div>
            <div class="form-group field-postform-format">
<label class="control-label col-sm-3" for="postform-format">Syntax Highlighting:</label>
<div class="col-sm-9 field-wrapper">
<div class="kv-plugin-loading loading-postform-format">&nbsp;</div><select id="postform-format" class="form-control" name="PostForm[format]" data-s2-options="s2options_7ebc6538" data-krajee-select2="select2_662ea3af" style="width: 1px; height: 1px; visibility: hidden;">
<option value="1" data-language="text">None</option>
<optgroup label="------ POPULAR LANGUAGES -------">
<option value="8" data-language="bash">Bash</option>
<option value="9" data-language="c">C</option>
<option value="14" data-language="csharp">C#</option>
<option value="13" data-language="cpp">C++</option>
<option value="16" data-language="css">CSS</option>
<option value="25" data-language="html4strict">HTML</option>
<option value="255" data-language="json">JSON</option>
<option value="27" data-language="java">Java</option>
<option value="28" data-language="javascript">JavaScript</option>
<option value="30" data-language="lua">Lua</option>
<option value="267" disabled data-language="markdown">Markdown (PRO members only)</option>
<option value="35" data-language="objc">Objective C</option>
<option value="41" data-language="php">PHP</option>
<option value="40" data-language="perl">Perl</option>
<option value="42" data-language="python">Python</option>
<option value="45" data-language="ruby">Ruby</option>
<option value="256" data-language="swift">Swift</option>
</optgroup>
<optgroup label="------ ALL LANGUAGES -------">
<option value="142" data-language="4cs">4CS</option>
<option value="143" data-language="6502acme">6502 ACME Cross Assembler</option>
<option value="144" data-language="6502kickass">6502 Kick Assembler</option>
<option value="145" data-language="6502tasm">6502 TASM/64TASS</option>
<option value="73" data-language="abap">ABAP</option>
<option value="236" data-language="aimms">AIMMS</option>
<option value="147" data-language="algol68">ALGOL 68</option>
<option value="75" data-language="apt_sources">APT Sources</option>
<option value="217" data-language="arm">ARM</option>
<option value="6" data-language="asm">ASM (NASM)</option>
<option value="7" data-language="asp">ASP</option>
<option value="2" data-language="actionscript">ActionScript</option>
<option value="74" data-language="actionscript3">ActionScript 3</option>
<option value="3" data-language="ada">Ada</option>
<option value="4" data-language="apache">Apache Log</option>
<option value="5" data-language="applescript">AppleScript</option>
<option value="270" data-language="arduino">Arduino</option>
<option value="218" data-language="asymptote">Asymptote</option>
<option value="54" data-language="autoit">AutoIt</option>
<option value="149" data-language="autohotkey">Autohotkey</option>
<option value="76" data-language="avisynth">Avisynth</option>
<option value="150" data-language="awk">Awk</option>
<option value="198" data-language="bascomavr">BASCOM AVR</option>
<option value="56" data-language="bnf">BNF</option>
<option value="80" data-language="boo">BOO</option>
<option value="8" data-language="bash">Bash</option>
<option value="77" data-language="basic4gl">Basic4GL</option>
<option value="20" data-language="dos">Batch</option>
<option value="78" data-language="bibtex">BibTeX</option>
<option value="55" data-language="blitzbasic">Blitz Basic</option>
<option value="259" data-language="b3d">Blitz3D</option>
<option value="260" data-language="bmx">BlitzMax</option>
<option value="79" data-language="bf">BrainFuck</option>
<option value="9" data-language="c">C</option>
<option value="252" data-language="c_winapi">C (WinAPI)</option>
<option value="82" data-language="cil">C Intermediate Language</option>
<option value="10" data-language="c_mac">C for Macs</option>
<option value="14" data-language="csharp">C#</option>
<option value="13" data-language="cpp">C++</option>
<option value="253" data-language="cpp-winapi">C++ (WinAPI)</option>
<option value="154" data-language="cpp-qt">C++ (with Qt extensions)</option>
<option value="199" data-language="c_loadrunner">C: Loadrunner</option>
<option value="11" data-language="caddcl">CAD DCL</option>
<option value="12" data-language="cadlisp">CAD Lisp</option>
<option value="81" data-language="cfdg">CFDG</option>
<option value="83" data-language="cmake">CMake</option>
<option value="84" data-language="cobol">COBOL</option>
<option value="16" data-language="css">CSS</option>
<option value="269" data-language="ceylon">Ceylon</option>
<option value="152" data-language="chaiscript">ChaiScript</option>
<option value="237" data-language="chapel">Chapel</option>
<option value="153" data-language="clojure">Clojure</option>
<option value="99" data-language="klonec">Clone C</option>
<option value="100" data-language="klonecpp">Clone C++</option>
<option value="200" data-language="coffeescript">CoffeeScript</option>
<option value="15" data-language="cfm">ColdFusion</option>
<option value="151" data-language="cuesheet">Cuesheet</option>
<option value="17" data-language="d">D</option>
<option value="219" data-language="dcl">DCL</option>
<option value="220" data-language="dcpu16">DCPU-16</option>
<option value="85" data-language="dcs">DCS</option>
<option value="86" data-language="div">DIV</option>
<option value="87" data-language="dot">DOT</option>
<option value="238" data-language="dart">Dart</option>
<option value="18" data-language="delphi">Delphi</option>
<option value="177" data-language="oxygene">Delphi Prism (Oxygene)</option>
<option value="19" data-language="diff">Diff</option>
<option value="155" data-language="e">E</option>
<option value="156" data-language="ecmascript">ECMAScript</option>
<option value="201" data-language="epc">EPC</option>
<option value="239" data-language="ezt">Easytrieve</option>
<option value="21" data-language="eiffel">Eiffel</option>
<option value="88" data-language="email">Email</option>
<option value="57" data-language="erlang">Erlang</option>
<option value="264" data-language="euphoria">Euphoria</option>
<option value="158" data-language="fsharp">F#</option>
<option value="89" data-language="fo">FO Language</option>
<option value="202" data-language="falcon">Falcon</option>
<option value="263" data-language="filemaker">Filemaker</option>
<option value="157" data-language="f1">Formula One</option>
<option value="22" data-language="fortran">Fortran</option>
<option value="23" data-language="freebasic">FreeBasic</option>
<option value="206" data-language="freeswitch">FreeSWITCH</option>
<option value="159" data-language="gambas">GAMBAS</option>
<option value="160" data-language="gdb">GDB</option>
<option value="287" data-language="gdscript">GDScript</option>
<option value="24" data-language="gml">Game Maker</option>
<option value="58" data-language="genero">Genero</option>
<option value="161" data-language="genie">Genie</option>
<option value="90" data-language="gettext">GetText</option>
<option value="162" data-language="go">Go</option>
<option value="288" data-language="godot-glsl">Godot GLSL</option>
<option value="59" data-language="groovy">Groovy</option>
<option value="163" data-language="gwbasic">GwBasic</option>
<option value="93" data-language="hq9plus">HQ9 Plus</option>
<option value="25" data-language="html4strict">HTML</option>
<option value="196" data-language="html5">HTML 5</option>
<option value="60" data-language="haskell">Haskell</option>
<option value="221" data-language="haxe">Haxe</option>
<option value="164" data-language="hicest">HicEst</option>
<option value="94" data-language="idl">IDL</option>
<option value="26" data-language="ini">INI file</option>
<option value="95" data-language="intercal">INTERCAL</option>
<option value="96" data-language="io">IO</option>
<option value="240" data-language="ispfpanel">ISPF Panel Definition</option>
<option value="165" data-language="icon">Icon</option>
<option value="61" data-language="inno">Inno Script</option>
<option value="166" data-language="j">J</option>
<option value="241" data-language="jcl">JCL</option>
<option value="255" data-language="json">JSON</option>
<option value="27" data-language="java">Java</option>
<option value="97" data-language="java5">Java 5</option>
<option value="28" data-language="javascript">JavaScript</option>
<option value="258" data-language="julia">Julia</option>
<option value="286" data-language="ksp">KSP (Kontakt Script)</option>
<option value="98" data-language="kixtart">KiXtart</option>
<option value="268" data-language="kotlin">Kotlin</option>
<option value="222" data-language="ldif">LDIF</option>
<option value="203" data-language="llvm">LLVM</option>
<option value="102" data-language="lolcode">LOL Code</option>
<option value="105" data-language="lscript">LScript</option>
<option value="62" data-language="latex">Latex</option>
<option value="168" data-language="lb">Liberty BASIC</option>
<option value="63" data-language="lsl2">Linden Scripting</option>
<option value="29" data-language="lisp">Lisp</option>
<option value="101" data-language="locobasic">Loco Basic</option>
<option value="169" data-language="logtalk">Logtalk</option>
<option value="103" data-language="lotusformulas">Lotus Formulas</option>
<option value="104" data-language="lotusscript">Lotus Script</option>
<option value="30" data-language="lua">Lua</option>
<option value="65" data-language="m68k">M68000 Assembler</option>
<option value="172" data-language="mmix">MIX Assembler</option>
<option value="278" data-language="mk-61">MK-61/52</option>
<option value="32" data-language="mpasm">MPASM</option>
<option value="108" data-language="mxml">MXML</option>
<option value="170" data-language="magiksf">MagikSF</option>
<option value="106" data-language="make">Make</option>
<option value="171" data-language="mapbasic">MapBasic</option>
<option value="267" disabled data-language="markdown">Markdown (PRO members only)</option>
<option value="64" data-language="matlab">MatLab</option>
<option value="276" data-language="mercury">Mercury</option>
<option value="277" data-language="metapost">MetaPost</option>
<option value="173" data-language="modula2">Modula 2</option>
<option value="107" data-language="modula3">Modula 3</option>
<option value="146" data-language="68000devpac">Motorola 68000 HiSoft Dev</option>
<option value="33" data-language="mysql">MySQL</option>
<option value="223" data-language="nagios">Nagios</option>
<option value="254" data-language="netrexx">NetRexx</option>
<option value="242" data-language="nginx">Nginx</option>
<option value="243" data-language="nim">Nim</option>
<option value="34" data-language="nsis">NullSoft Installer</option>
<option value="36" data-language="ocaml">OCaml</option>
<option value="110" data-language="ocaml-brief">OCaml Brief</option>
<option value="109" data-language="oberon2">Oberon 2</option>
<option value="175" data-language="objeck">Objeck Programming Langua</option>
<option value="35" data-language="objc">Objective C</option>
<option value="224" data-language="octave">Octave</option>
<option value="266" data-language="oorexx">Open Object Rexx</option>
<option value="181" data-language="pf">OpenBSD PACKET FILTER</option>
<option value="91" data-language="glsl">OpenGL Shading</option>
<option value="37" data-language="oobas">Openoffice BASIC</option>
<option value="111" data-language="oracle11">Oracle 11</option>
<option value="38" data-language="oracle8">Oracle 8</option>
<option value="178" data-language="oz">Oz</option>
<option value="226" data-language="parigp">PARI/GP</option>
<option value="179" data-language="pcre">PCRE</option>
<option value="41" data-language="php">PHP</option>
<option value="113" data-language="php-brief">PHP Brief</option>
<option value="265" data-language="pli">PL/I</option>
<option value="68" data-language="plsql">PL/SQL</option>
<option value="116" data-language="povray">POV-Ray</option>
<option value="225" data-language="parasail">ParaSail</option>
<option value="39" data-language="pascal">Pascal</option>
<option value="141" data-language="pawn">Pawn</option>
<option value="112" data-language="per">Per</option>
<option value="40" data-language="perl">Perl</option>
<option value="180" data-language="perl6">Perl 6</option>
<option value="279" data-language="phix">Phix</option>
<option value="114" data-language="pic16">Pic 16</option>
<option value="182" data-language="pike">Pike</option>
<option value="115" data-language="pixelbender">Pixel Bender</option>
<option value="244" data-language="postscript">PostScript</option>
<option value="183" data-language="postgresql">PostgreSQL</option>
<option value="184" data-language="powerbuilder">PowerBuilder</option>
<option value="117" data-language="powershell">PowerShell</option>
<option value="197" data-language="proftpd">ProFTPd</option>
<option value="118" data-language="progress">Progress</option>
<option value="119" data-language="prolog">Prolog</option>
<option value="120" data-language="properties">Properties</option>
<option value="121" data-language="providex">ProvideX</option>
<option value="262" data-language="puppet">Puppet</option>
<option value="185" data-language="purebasic">PureBasic</option>
<option value="204" data-language="pycon">PyCon</option>
<option value="42" data-language="python">Python</option>
<option value="227" data-language="pys60">Python for S60</option>
<option value="43" data-language="qbasic">QBasic</option>
<option value="245" data-language="qml">QML</option>
<option value="188" data-language="rsplus">R</option>
<option value="247" data-language="rbs">RBScript</option>
<option value="122" data-language="rebol">REBOL</option>
<option value="123" data-language="reg">REG</option>
<option value="187" data-language="rpmspec">RPM Spec</option>
<option value="246" data-language="racket">Racket</option>
<option value="67" data-language="rails">Rails</option>
<option value="228" data-language="rexx">Rexx</option>
<option value="44" data-language="robots">Robots</option>
<option value="280" data-language="roff">Roff Manpage</option>
<option value="45" data-language="ruby">Ruby</option>
<option value="92" data-language="gnuplot">Ruby Gnuplot</option>
<option value="248" data-language="rust">Rust</option>
<option value="124" data-language="sas">SAS</option>
<option value="249" data-language="scl">SCL</option>
<option value="229" data-language="spark">SPARK</option>
<option value="230" data-language="sparql">SPARQL</option>
<option value="261" data-language="sqf">SQF</option>
<option value="48" data-language="sql">SQL</option>
<option value="282" data-language="sshconfig">SSH Config</option>
<option value="125" data-language="scala">Scala</option>
<option value="46" data-language="scheme">Scheme</option>
<option value="126" data-language="scilab">Scilab</option>
<option value="127" data-language="sdlbasic">SdlBasic</option>
<option value="69" data-language="smalltalk">Smalltalk</option>
<option value="47" data-language="smarty">Smarty</option>
<option value="250" data-language="standardml">StandardML</option>
<option value="231" data-language="stonescript">StoneScript</option>
<option value="257" data-language="sclang">SuperCollider</option>
<option value="256" data-language="swift">Swift</option>
<option value="189" data-language="systemverilog">SystemVerilog</option>
<option value="130" data-language="tsql">T-SQL</option>
<option value="70" data-language="tcl">TCL</option>
<option value="283" data-language="texgraph">TeXgraph</option>
<option value="128" data-language="teraterm">Tera Term</option>
<option value="272" data-language="typescript">TypeScript</option>
<option value="131" data-language="typoscript">TypoScript</option>
<option value="232" data-language="upc">UPC</option>
<option value="191" data-language="unicon">Unicon</option>
<option value="195" data-language="uscript">UnrealScript</option>
<option value="233" data-language="urbi">Urbi</option>
<option value="51" data-language="vbnet">VB.NET</option>
<option value="251" data-language="vbscript">VBScript</option>
<option value="133" data-language="vhdl">VHDL</option>
<option value="134" data-language="vim">VIM</option>
<option value="192" data-language="vala">Vala</option>
<option value="234" data-language="vedit">Vedit</option>
<option value="132" data-language="verilog">VeriLog</option>
<option value="135" data-language="visualprolog">Visual Pro Log</option>
<option value="50" data-language="vb">VisualBasic</option>
<option value="52" data-language="visualfoxpro">VisualFoxPro</option>
<option value="137" data-language="whois">WHOIS</option>
<option value="136" data-language="whitespace">WhiteSpace</option>
<option value="138" data-language="winbatch">Winbatch</option>
<option value="193" data-language="xbasic">XBasic</option>
<option value="53" data-language="xml">XML</option>
<option value="140" data-language="xpp">XPP</option>
<option value="285" data-language="xojo">Xojo</option>
<option value="139" data-language="xorg_conf">Xorg Config</option>
<option value="205" data-language="yaml">YAML</option>
<option value="271" data-language="yara">YARA</option>
<option value="72" data-language="z80">Z80 Assembler</option>
<option value="194" data-language="zxbasic">ZXBasic</option>
<option value="148" data-language="autoconf">autoconf</option>
<option value="167" data-language="jquery">jQuery</option>
<option value="66" data-language="mirc">mIRC</option>
<option value="174" data-language="newlisp">newLISP</option>
<option value="186" data-language="q">q/kdb+</option>
<option value="129" data-language="thinbasic">thinBasic</option>
</optgroup>
</select>

</div>
</div>
            <div class="form-group field-postform-expiration">
<label class="control-label col-sm-3" for="postform-expiration">Paste Expiration:</label>
<div class="col-sm-9 field-wrapper">
<div class="kv-plugin-loading loading-postform-expiration">&nbsp;</div><select id="postform-expiration" class="form-control" name="PostForm[expiration]" data-s2-options="s2options_7ebc6538" data-krajee-select2="select2_a09a7382" style="width: 1px; height: 1px; visibility: hidden;">
<option value="N">Never</option>
<option value="B">Burn after read</option>
<option value="10M">10 Minutes</option>
<option value="1H">1 Hour</option>
<option value="1D">1 Day</option>
<option value="1W">1 Week</option>
<option value="2W">2 Weeks</option>
<option value="1M">1 Month</option>
<option value="6M">6 Months</option>
<option value="1Y">1 Year</option>
</select>

</div>
</div>
            <div class="form-group field-postform-status">
<label class="control-label col-sm-3" for="postform-status">Paste Exposure:</label>
<div class="col-sm-9 field-wrapper">
<div class="kv-plugin-loading loading-postform-status">&nbsp;</div><select id="postform-status" class="form-control" name="PostForm[status]" data-s2-options="s2options_7ebc6538" data-krajee-select2="select2_a09a7382" style="width: 1px; height: 1px; visibility: hidden;">
<option value="0">Public</option>
<option value="1">Unlisted</option>
<option value="2" disabled>Private</option>
</select>

</div>
</div>
            <div class="post-form__folder">
                <div class="form-group field-postform-folder_key">
<label class="control-label col-sm-3" for="postform-folder_key">Folder:</label>
<div class="col-sm-9 field-wrapper">
<div class="kv-plugin-loading loading-postform-folder_key">&nbsp;</div><select id="postform-folder_key" class="form-control" name="PostForm[folder_key]" data-s2-options="s2options_7ebc6538" data-krajee-select2="select2_a09a7382" style="width: 1px; height: 1px; visibility: hidden;">
<option value="1" disabled>(members only)</option>
</select>

</div>
</div>
                            </div>

            
            <div class="form-group field-postform-is_password_enabled">
                <label class="control-label col-sm-3">Password<span class="badge-new">NEW</span></label>
                <div class="col-sm-9 field-wrapper">
                    
<input type="hidden" name="PostForm[is_password_enabled]" value="0"><input type="checkbox" id="postform-is_password_enabled" class="js-is-password-enabled" name="PostForm[is_password_enabled]" value="1">
<label for="postform-is_password_enabled">
<span></span><span class="green js-is-password-enabled-label hide">Enabled</span><span class="js-is-password-enabled-label ">Disabled</span>
</label>
                </div>

                <div style="clear: both"></div>
                
<label class="control-label col-sm-3" for="postform-password"> </label>
<div class="col-sm-9 field-wrapper">
<input type="text" id="postform-password" class="form-control js-password" name="PostForm[password]" disabled maxlength="64" aria-label="Password">

</div>
            </div>

            <div class="form-group field-postform-is_burn">
                <div class="col-sm-9 col-sm-offset-3">
                    
<input type="hidden" name="PostForm[is_burn]" value="0"><input type="checkbox" id="postform-is_burn" class="js-burn" name="PostForm[is_burn]" value="1">
<label for="postform-is_burn">
<span></span>Burn after read
</label><span class='badge-new'>NEW</span>
                </div>
            </div>

            <div class="form-group field-postform-name">
<label class="control-label col-sm-3" for="postform-name">Paste Name / Title:</label>
<div class="col-sm-9 field-wrapper">
<input type="text" id="postform-name" class="form-control" name="PostForm[name]" maxlength="100">

</div>
</div>
            <div class="form-group form-btn-container">
                <button type="submit" class="btn -big">Create New Paste</button>
                            </div>
        </div>

        <div class="post-form__right h_800">

            
                <div class="post-form__user">
                    <div class="post-form__avatar">
                        <img src="/themes/pastebin/img/guest.webp" alt="Guest User">                    </div>
                    <div class="post-form__text">
                        <div class="post-form__name">
                            Hello <b>Guest</b>                        </div>
                        <div class="post-form__sign">
                            <a href="/signup" class="btn">Sign Up</a>&nbsp;or&nbsp;<a href="/login" class="btn">Login</a>
                        </div>
                    </div>
                </div>

                <div class="post-form__oauth">
                    <a class="post-form__link -facebook" href="/site/auth-facebook">Sign in with Facebook</a>                    <a class="post-form__link -twitter" href="/site/auth-twitter">Sign in with Twitter</a>                    <a class="post-form__link -google" href="/site/auth-google">Sign in with Google</a>                </div>

            
                        
<!-- 0-EykQt2a9 -->
<div style="padding-bottom:20px; padding-top:20px;">
<script>
  atOptions = {
    'key' : '2d659391b8040baf390cdad136ed5493',
    'format' : 'iframe',
    'height' : 250,
    'width' : 300,
    'params' : {}
  };
</script>
<script src="https://www.highrevenueformat.com/2d659391b8040baf390cdad136ed5493/invoke.js"></script>
</div>

        </div>
    </div>

    </form>
    
            
<div class="page">
    <div class="content__text">
        <div class="notice -post-form">You are currently not logged in, this means you can not edit or delete anything you paste. <a href="/signup">Sign Up</a> or <a href="/login">Login</a></div>
    </div>
</div>    
</div>
</div>            <div style="clear: both;"></div>

                                </div>

        <div class="sidebar h_1024">
            



                
    <div class="sidebar__title">
        <a href="/archive">Public Pastes</a>
    </div>
    <ul class="sidebar__menu">

                    <li>
                <a href="/cbEvCCn8?source=public_pastes">I made $15,000 * 2 hours</a>
                <div class="details">
                                            CSS |
                    
                    9 min ago
                    | 0.99 KB                </div>
            </li>
                    <li>
                <a href="/kqm8QU6p?source=public_pastes">✅ API Glitch (Docs Leak)</a>
                <div class="details">
                                            CSS |
                    
                    12 min ago
                    | 0.99 KB                </div>
            </li>
                    <li>
                <a href="/pfg2iBvJ?source=public_pastes">notes</a>
                <div class="details">
                    
                    18 hours ago
                    | 0.06 KB                </div>
            </li>
                    <li>
                <a href="/2701iMCd?source=public_pastes">tkounter.py</a>
                <div class="details">
                                            PowerShell |
                    
                    18 hours ago
                    | 0.57 KB                </div>
            </li>
                    <li>
                <a href="/xmMKWgdv?source=public_pastes">notes</a>
                <div class="details">
                    
                    21 hours ago
                    | 0.31 KB                </div>
            </li>
                    <li>
                <a href="/14nz5dH0?source=public_pastes">[TLF 17] &quot;Random&quot; Interrogation.</a>
                <div class="details">
                    
                    23 hours ago
                    | 5.32 KB                </div>
            </li>
                    <li>
                <a href="/SPRCRAYN?source=public_pastes">Icod TUI</a>
                <div class="details">
                    
                    1 day ago
                    | 2.44 KB                </div>
            </li>
                    <li>
                <a href="/KQ6b3PAn?source=public_pastes">chalets</a>
                <div class="details">
                    
                    1 day ago
                    | 1.05 KB                </div>
            </li>
        
    </ul>
            

    <div class="sidebar__sticky -on">
                
<!-- 0-EykQt2a9 -->
<div style="padding-bottom:10px; padding-top:20px;">
<div class="adsbyvli" style="width:300px; height:250px" data-ad-slot="vi_1282566940"></div> <script>(vitag.Init = window.vitag.Init || []).push(function () { viAPItag.display("vi_1282566940") })</script>
</div>

    </div>
        </div>
    </div>
</div>


    
<div class="top-footer">
    <a class="icon-link -size-24-24 -chrome" href="/tools#chrome" title="Google Chrome Extension"></a>
    <a class="icon-link -size-24-24 -firefox" href="/tools#firefox" title="Firefox Extension"></a>
    <a class="icon-link -size-24-24 -iphone" href="/tools#iphone" title="iPhone/iPad Application"></a>
    <a class="icon-link -size-24-24 -windows" href="/tools#windows" title="Windows Desktop Application"></a>
    <a class="icon-link -size-24-24 -android" href="/tools#android" title="Android Application"></a>
    <a class="icon-link -size-24-24 -macos" href="/tools#macos" title="MacOS X Widget"></a>
    <a class="icon-link -size-24-24 -opera" href="/tools#opera" title="Opera Extension"></a>
    <a class="icon-link -size-24-24 -unix" href="/tools#pastebincl" title="Linux Application"></a>
</div>

<footer class="footer">
    <div class="container">
        <div class="footer__container">

            <div class="footer__left">
                <a href="/">create new paste</a> <span class="footer__devider">&nbsp;/&nbsp;</span>
                                <a href="/languages">syntax languages</a> <span class="footer__devider">&nbsp;/&nbsp;</span>
                <a href="/archive">archive</a> <span class="footer__devider">&nbsp;/&nbsp;</span>
                <a href="/faq">faq</a> <span class="footer__devider">&nbsp;/&nbsp;</span>
                <a href="/tools">tools</a> <span class="footer__devider">&nbsp;/&nbsp;</span>
                <a href="/night_mode">night mode</a> <span class="footer__devider">&nbsp;/&nbsp;</span>
                <a href="/doc_api">api</a> <span class="footer__devider">&nbsp;/&nbsp;</span>
                <a href="/doc_scraping_api">scraping api</a> <span class="footer__devider">&nbsp;/&nbsp;</span>
                <a href="/news">news</a> <span class="footer__devider">&nbsp;/&nbsp;</span>
                <a href="/pro" class="pro">pro</a>

                <br>
                <a href="/doc_privacy_statement">privacy statement</a> <span class="footer__devider">&nbsp;/&nbsp;</span>
                <a href="/doc_cookies_policy">cookies policy</a> <span class="footer__devider">&nbsp;/&nbsp;</span>
                <a href="/doc_terms_of_service">terms of service</a><span class="footer__devider">&nbsp;/&nbsp;</span>
                <a href="/doc_security_disclosure">security disclosure</a> <span class="footer__devider">&nbsp;/&nbsp;</span>
                <a href="/dmca">dmca</a> <span class="footer__devider">&nbsp;/&nbsp;</span>
                <a href="/report-abuse">report abuse</a> <span class="footer__devider">&nbsp;/&nbsp;</span>
                <a href="/contact">contact</a>

                <br>

                                
                <br>

                
<span class="footer__bottom h_800">
    By using Pastebin.com you agree to our <a href="/doc_cookies_policy">cookies policy</a> to enhance your experience.
    <br>
    Site design &amp; logo &copy; 2026 Pastebin</span>
            </div>

            <div class="footer__right h_1024">
                                    <a class="icon-link -size-40-40 -facebook-circle" href="https://facebook.com/pastebin" rel="nofollow" title="Like us on Facebook" target="_blank"></a>
                    <a class="icon-link -size-40-40 -twitter-circle" href="https://twitter.com/pastebin" rel="nofollow" title="Follow us on Twitter" target="_blank"></a>
                            </div>

        </div>
    </div>
</footer>
    


    
<div class="popup-container">

                <div class="popup-box -cookies" data-name="l2c_1">
            We use cookies for various purposes including analytics. By continuing to use Pastebin, you agree to our use of cookies as described in the <a href="/doc_cookies_policy">Cookies Policy</a>.            &nbsp;<span class="cookie-button js-close-cookies">OK, I Understand</span>
        </div>
    
                <div class="popup-box -pro" data-name="l2c_2_pg">
            <div class="pro-promo-img">
                <a href="/signup" aria-label="Sign Up">
                    <img src="/themes/pastebin/img/hello.webp" alt=""/>
                </a>
            </div>
            <div class="pro-promo-text">
                Not a member of Pastebin yet?<br/>
                <a href="/signup"><b>Sign Up</b></a>, it unlocks many cool features!            </div>
            <div class="close js-close-pro-guest" title="Close Me">&nbsp;</div>
        </div>
    
    
    
</div>
    

<span class="cd-top"></span>

<script src="/assets/9ce1885/jquery.min.js"></script>
<script src="/assets/f04f76b8/yii.js"></script>
<script src="/assets/ff2ff0b/js/select2.full.min.js"></script>
<script src="/assets/c19c6973/js/select2-krajee.min.js"></script>
<script src="/assets/fb16b45a/js/kv-widgets.min.js"></script>
<script src="/assets/f04f76b8/yii.activeForm.js"></script>
<script src="/assets/d65ff796/dist/bootstrap-tagsinput.js"></script>
<script>jQuery(function ($) {
jQuery('#postform-tag').tagsinput({'trimValue':true});
        
jQuery&&jQuery.pjax&&(jQuery.pjax.defaults.maxCacheLength=0);
if (jQuery('#postform-format').data('select2')) { jQuery('#postform-format').select2('destroy'); }
jQuery.when(jQuery('#postform-format').select2(select2_662ea3af)).done(initS2Loading('postform-format','s2options_7ebc6538'));

if (jQuery('#postform-expiration').data('select2')) { jQuery('#postform-expiration').select2('destroy'); }
jQuery.when(jQuery('#postform-expiration').select2(select2_a09a7382)).done(initS2Loading('postform-expiration','s2options_7ebc6538'));

if (jQuery('#postform-category_id').data('select2')) { jQuery('#postform-category_id').select2('destroy'); }
jQuery.when(jQuery('#postform-category_id').select2(select2_662ea3af)).done(initS2Loading('postform-category_id','s2options_7ebc6538'));

if (jQuery('#postform-status').data('select2')) { jQuery('#postform-status').select2('destroy'); }
jQuery.when(jQuery('#postform-status').select2(select2_a09a7382)).done(initS2Loading('postform-status','s2options_7ebc6538'));

if (jQuery('#postform-folder_key').data('select2')) { jQuery('#postform-folder_key').select2('destroy'); }
jQuery.when(jQuery('#postform-folder_key').select2(select2_a09a7382)).done(initS2Loading('postform-folder_key','s2options_7ebc6538'));

jQuery('#w0').yiiActiveForm([], []);
});</script>
<script>
    const POST_EXPIRATION_NEVER = 'N';
    const POST_EXPIRATION_BURN = 'B';
    const POST_STATUS_PUBLIC = '0';
    const POST_STATUS_UNLISTED = '1';
</script>
<script src="/themes/pastebin/js/vendors.bundle.js?30d6ece6979ee0cf5531"></script>
<script src="/themes/pastebin/js/app.bundle.js?30d6ece6979ee0cf5531"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/codemirror/5.58.2/codemirror.min.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/codemirror/5.58.2/addon/mode/multiplex.min.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/codemirror/5.58.2/addon/mode/simple.min.js"></script>
</body>
</html>
