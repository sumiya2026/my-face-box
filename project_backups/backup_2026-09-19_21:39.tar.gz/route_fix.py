import os

app_path = "app.py"

if os.path.exists(app_path):
    with open(app_path, "r", encoding="utf-8") as f:
        code = f.read()

    # සර්වර් එක මුලින්ම ලෝඩ් වෙද්දී index.html (ප්‍රධාන Feed පිටුව) පෙන්වීමට කේතය සැකසීම
    main_route_code = """
@app.route('/')
def home():
    import os
    if os.path.exists('index.html'):
        with open('index.html', 'r', encoding='utf-8') as f:
            return f.read()
    return "index.html not found"
"""

    # පැරණි '/' route එකක් ඇත්නම් එය ඉවත් කර නව එක ඇතුළත් කිරීම
    if "@app.route('/')" in code:
        # සරලව කේතයේ අගට එකතු කරමු, Flask වල අලුත් route එකක් උඩින් ක්‍රියාත්මක වේ
        code = code.replace("@app.route('/')", "@app.route('/old-register')")
    
    if "def home():" not in code:
        if "if __name__" in code:
            code = code.replace("if __name__", f"{main_route_code}\nif __name__")
        else:
            code += main_route_code

    with open(app_path, "w", encoding="utf-8") as f:
        f.write(code)
    print("[SUCCESS] Server configured to load your main Feed page first!")
else:
    print("[ERROR] app.py not found.")
