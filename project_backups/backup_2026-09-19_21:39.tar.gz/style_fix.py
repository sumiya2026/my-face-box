import os

html_path = "index.html"

if os.path.exists(html_path):
    with open(html_path, "r", encoding="utf-8") as f:
        content = f.read()

    # වැරදියට හැමතැනම රීප්ලේස් වුණු style කොටස නැවත සාමාන්‍ය තත්ත්වයට පත් කිරීම
    wrong_style = "onclick=\"document.getElementById('signupModal').style.display='flex'\" style=\""
    content = content.replace(wrong_style, 'style="')

    # දැන් යටම තියෙන "Verify Identity & Create Account" බොත්තමට විතරක් නිවැරදිව onclick එක දීම
    target_btn = 'data-i18n="verifyBtn">Verify Identity & Create Account (Real Users Only)'
    if target_btn in content:
        content = content.replace(target_btn, target_btn + '" onclick="document.getElementById(\'signupModal\').style.display=\'flex\'')
    elif "Verify Identity & Create Account" in content:
        content = content.replace("Verify Identity & Create Account", "Verify Identity & Create Account\" onclick=\"document.getElementById('signupModal').style.display='flex'")

    with open(html_path, "w", encoding="utf-8") as f:
        f.write(content)
    print("[SUCCESS] HTML layout and styles restored successfully!")
else:
    print("[ERROR] index.html not found.")
