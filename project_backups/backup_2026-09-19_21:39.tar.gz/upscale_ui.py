import os

html_path = "index.html"

if os.path.exists(html_path):
    with open(html_path, "r", encoding="utf-8") as f:
        content = f.read()

    # ජංගම දුරකථන තිර සඳහා අකුරු සහ මූලද්‍රව්‍ය 3x විශාල කිරීමට අවශ්‍ය CSS මෝස්තර කේතය
    giant_style_code = """
    <meta name="viewport" content="width=device-width, initial-scale=3.0, user-scalable=yes">
    <style>
        /* මුළු පිටුවේම අකුරු සහ මූලික හැඩතල විශාල කිරීම */
        body {
            font-size: 24px !important;
            font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, Helvetica, Arial, sans-serif;
            
            margin: 0;
            padding: 0;
        }
        
        /* ඉහළ තීරුව (Header) සහ ලෝගෝ එක විශාල කිරීම */
        header, .header-container, #header {
            padding: 20px !important;
            font-size: 32px !important;
            height: auto !important;
        }
        
        /* My Face BOX ප්‍රධාන අකුර */
        h1, .logo, [data-i18n="title"] {
            font-size: 48px !important;
            font-weight: bold !important;
        }

        /* What's on your mind? Input තීරුව විශාල කිරීම */
        input[type="text"], textarea, .search-bar, .input-container input {
            font-size: 26px !important;
            padding: 20px !important;
            border-radius: 40px !important;
            height: auto !important;
        }

        /* බොත්තම් (Buttons) සහ මෙනු විශාල කිරීම */
        button, .btn, #langSelect {
            font-size: 26px !important;
            padding: 15px 30px !important;
            border-radius: 30px !important;
        }

        /* භාෂා තෝරන මෙනුව ජංගම දුරකථනයට පැහැදිලිව පෙනීමට සැකසීම */
        .language-selector, #langSelect {
            font-size: 24px !important;
            padding: 10px 20px !important;
        }

        /* Stories සහ Feed පෝස්ට් කාඩ්ස් විශාල කිරීම */
        .story-container, .feed-container, .card, .post {
            max-width: 100% !important;
            width: 100% !important;
            margin-top: 20px !important;
            padding: 25px !important;
            border-radius: 15px !important;
        }

        .post-text, .post p, .comment-text {
            font-size: 28px !important;
            line-height: 1.5 !important;
        }

        /* පින්තූර සහ වීඩියෝ සම්පූර්ණ තිරයට ලස්සනට පෙනීමට සැලැස්වීම */
        .post-image, .post img, img {
            width: 100% !important;
            height: auto !important;
            border-radius: 10px !important;
        }
    </style>
    """

    # පවතින </head> ටැගයට පෙර මෙම 3x විශාල කරන මෝස්තර ඇතුළත් කිරීම
    if "</head>" in content:
        content = content.replace("</head>", f"{giant_style_code}\n</head>")

    with open(html_path, "w", encoding="utf-8") as f:
        f.write(content)
    print("[SUCCESS] App interface and font size successfully increased by 3x!")
else:
    print("[ERROR] index.html not found.")
