from flask import Flask, render_template, jsonify, request

app = Flask(__name__)

@app.route('/')
def home():
    return render_template('index.html')

@app.route('/videos')
def videos():
    return render_template('videos.html')

@app.route('/friends')
def friends():
    return render_template('friends.html')

@app.route('/marketplace')
def marketplace():
    return render_template('marketplace.html')

@app.route('/notifications')
def notifications():
    return render_template('notifications.html')

@app.route('/menu')
def menu():
    return render_template('menu.html')

@app.route('/add-post')
def add_post():
    return render_template('add_post.html')

@app.route('/search')
def search():
    return render_template('search.html')

@app.route('/messages')
def messages():
    return render_template('messages.html')

if __name__ == '__main__':
    app.run(debug=True, host='0.0.0.0', port=8000)
